#include "udf.h"

/* Initializing the fields using UDFs */
DEFINE_INIT(tv_init,d)
{
        cell_t c        ;
        Thread  *t      ;
        real temp,theta1,theta2,theta3,Ru,e;
        real MW1, MW2, MW3;
 
        theta1	= 3395.0;
		theta2  = 2239.0;
		theta3  = 2817.0;
        e	= 2.718281;
        Ru	= 8314.0;
        MW1     = 28.0134; 
		MW2     = 31.988;
		MW3 	= 30.0061;
/* Loop over all cell threads in the domain */
  thread_loop_c(t,d)
        {
           /* loop over all cells */
                begin_c_loop_all(c,t)
                {
                temp	      = C_T(c,t);
                C_UDMI(c,t,0) = temp;
				C_UDMI(c,t,1) = temp;
				C_UDMI(c,t,2) = temp;
                C_UDSI(c,t,0) = theta1*Ru/(MW1*(pow(e,theta1/temp)-1));
				C_UDSI(c,t,1) = theta2*Ru/(MW2*(pow(e,theta2/temp)-1));
				C_UDSI(c,t,2) = theta3*Ru/(MW3*(pow(e,theta2/temp)-1));
                }
                end_c_loop_all(c,t)
        }
}

/* Adjust UDFs for computing the vibrational
 * temperature and manipulating the field
 * during ongoing simulations */
DEFINE_ADJUST(tv_comp,d)
{
        Thread *t;
        cell_t c ;
        real enerV1,enerV2, enerV3;
        real thetaV1 =3395.0;
		real thetaV2 =2239.0;
		real thetaV3 =2817.0;
        real MW1 = 28.0134;
		real MW2 = 31.9988;
		real MW3 = 30.0061;
        real Ru = 8314.0;
        real Tv1, Tv2, Tv3;

        /* Loop over all the thread */
        thread_loop_c (t,d)
        {
                begin_c_loop (c,t)
                {
                enerV1 = C_UDSI(c,t,0);
				enerV2 = C_UDSI(c,t,1);
				enerV3 = C_UDSI(c,t,2);
                Tv1 = thetaV1*pow(log((thetaV1*Ru/(MW1*enerV1))+1),-1);
				Tv2 = thetaV2*pow(log((thetaV2*Ru/(MW2*enerV2))+1),-1);
				Tv3 = thetaV3*pow(log((thetaV3*Ru/(MW3*enerV3))+1),-1);
                C_UDMI(c,t,0) = Tv1;
				C_UDMI(c,t,1) = Tv2;
				C_UDMI(c,t,2) = Tv3;
                }
                end_c_loop (c,t)
        }
}

/* Diffusion coefficents used in the UDS equations 
 * computed using UDFs using Hilfelshders
 * formulation for temperature dependent viscosity */
DEFINE_DIFFUSIVITY(mun2,c,t,i)
{
        real mu;
        real MW = 28.0134;
        real CsR;
        real temp;
        real A_22 = -7.6303990E-3 ;
        real B_22 = 1.6878089E-1  ;
        real C_22 = -1.4004234E0 ;
        real D_22 = 2.1427708E3   ;

        temp  = C_T(c,t);
        CsR   = D_22*pow(temp,((A_22*log(temp)+B_22)*log(temp)+C_22));
        mu    = 2.6693E-6*3.14125*pow(MW*temp,0.5)/CsR ;
        C_UDMI(c,t,3) = mu;
        return mu;
}

DEFINE_DIFFUSIVITY(muo2,c,t,i)
{
        real mu;
        real MW = 31.9988;
        real CsR;
        real temp;
        real A_22 = -6.2931612E-3 ;
        real B_22 = 1.6626193E−1  ;
        real C_22 = -1.4107027E0 ;
        real D_22 = 2.3097604E3   ;

        temp  = C_T(c,t);
        CsR   = D_22*pow(temp,((A_22*log(temp)+B_22)*log(temp)+C_22));
        mu    = 2.6693E-6*3.14125*pow(MW*temp,0.5)/CsR ;
        C_UDMI(c,t,4) = mu;
        return mu;
}

DEFINE_DIFFUSIVITY(muno,c,t,i)
{
        real mu;
        real MW = 30.0061;
        real CsR;
        real temp;
        real A_22 = -7.4942466E-3 ;
        real B_22 = 1.4624645E−1  ;
        real C_22 = -1.3006927E0 ;
        real D_22 = 1.8066892E3   ;

        temp  = C_T(c,t);
        CsR   = D_22*pow(temp,((A_22*log(temp)+B_22)*log(temp)+C_22));
        mu    = 2.6693E-6*3.14125*pow(MW*temp,0.5)/CsR ;
        C_UDMI(c,t,5) = mu;
        return mu;
}


/* Vibrational-Translational relaxation source 
 * term for N2 is computed using Landaue-Teller model
 * is coded up as a source UDF               */
DEFINE_SOURCE(vt_source_N2,c,t,dS,eqn)
{
real    vt,msr,MW,theta;
real    xr,tau_sr,Asr,temp;
real    pres,e,C_temp,tau_vs;
real    density, Ys,tempV;
real    evsT,evsTV,Ru,NA;
real    tau_cs,sig_s,C_s,n_s;

e       = 2.718281828   ;
NA      = 6.0221476E23  ;
MW1     = 28.0134       ; /*N2*/
MW2     = 31.9988		; /*O2*/
MW3     = 30.0061		; /*NO*/
MW4     = MW1/2			; /*N*/
MW5     = MW2/2			; /*O*/
theta   = 3.395E+3      ;
Ru      = 8314.0        ;

/* for N2,N2 */
mN2N2     = (MW1*MW1)/(MW1+MW1)        ;
/* for N2,O2 */
mN2O2     = (MW1*MW2)/(MW1+MW2)        ;
/* for N2,NO */
mN2NO 	= (MW1*MW3)/(MW1+MW3)		   ;
/* for N2,N */
mN2N 	= (MW1*MW4)/(MW1+MW4)		   ;
/* for N2,O */
mN2O 	= (MW1*MW5)/(MW1+MW5)		   ;

temp    = C_T(c,t)      ;
pres    = C_P(c,t)      ;
density = C_R(c,t)      ;
Ys      = C_YI(c,t,0)   ;
Asr     = 1.16E-3*pow(msr,0.5)*pow(theta,4/3);
C_temp  = Asr*(pow(temp,-1/3)-0.015*pow(msr,0.25))-18.42;
tau_sr  = (101325.0/pres)*pow(e,C_temp);

/* Parks correction */

sig_s   = 1E-20*pow(50000/temp,2);
C_s     = pow(8*Ru*temp/(3.14125*MW),0.5);
n_s     = NA*density*Ys/MW;
tau_cs  = pow(sig_s*C_s*n_s,-1);

/* Since we have only one diatomic species at this 
 *  * point, we have to just add the two relaxation 
 *   * time steps to get tau_vs */
tau_vs  = tau_sr+tau_cs;

tempV   = C_UDMI(c,t,0) ;
evsT    = theta*Ru/(MW*(pow(e,theta/temp)-1));
evsTV   = C_UDSI(c,t,0);
/*  Landau-Teller formula */
vt      = density*Ys*(evsT-evsTV)/tau_vs;
C_UDMI(c,t,6) = vt;
C_UDMI(c,t,7) = tau_vs;

return vt;
}

DEFINE_SOURCE(e_vt_source_N2,c,t,dS,eqn)
{
real    evt;
evt     = -1*C_UDMI(c,t,6);
return evt;
}

/* Here we add the diffusion flux vector to the momentum vector */


