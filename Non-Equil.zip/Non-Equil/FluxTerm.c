#include "udf.h"

# FLUX TERM FOR N2 TRANSPORT

DEFINE_UDS_FLUX(my_flux,f,t,i)
{
  cell_t c;
  Thread *t;
  face_t f;
  Thread *tf;
  int n;
  
  real NV_VEC(mom_vec),real NV_VEC(J_vec),NV_VEC(A), diffscalar, flux = 0.0;
  
  diffscalar = -1*C_R(c,t)*C_DIFF_EFF(c,t,0)
  NV_DS(mom_vec,  =, C_U_RG(c,t), C_V_RG(c,t), C_W_RG(c,t), *, C_R(c,t));
  NV_DS(J_vec, =, C_YI_RG(c,t,0)[0],C_YI_RG(c,t,0)[1],C_YI_RG(c,t,0)[2], *, diffscalar);
  NV_VV(psi_vec,=,mom_vec,+, J_vec); /* total transport vector (rho*v)+ J */
  
  c_face_loop(c, t, n)         /* loops over all faces of a cell */
  {
	  f = C_FACE(c,t,n);
	  tf = C_FACE_THREAD(c,t,n);
	  F_AREA(A,f,tf);
	  flux = NV_DOT(psi_vec,A);
  }

  return flux;
}